import { Add, Point } from "./module";

console.log(`The addition is : ${Add(20, 30)}`);
let point = new Point(100, 200);
point.getPointDetails();
