export class Point {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  getPointDetails() {
    console.log("[X = " + this.x + " , Y = " + this.y + "]");
  }
}

const PI = 3.14;

export var Add = (x, y) => x + y;
